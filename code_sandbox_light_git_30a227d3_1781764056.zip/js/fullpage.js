/**
 * fullpage.js
 * Поэкранный скроллинг — плавный переход между секциями
 * Управление: колесо мыши, стрелки, touch-свайп, dot-nav
 */
(function () {
  'use strict';

  const fp      = document.getElementById('fullpage');
  const dots    = document.querySelectorAll('.fp-dot');
  const sections = document.querySelectorAll('#fullpage > section, #fullpage > footer');

  if (!fp || !sections.length) return;

  let current  = 0;
  let isMoving = false;
  const TOTAL  = sections.length;
  const LOCK_MS = 900; // блокировка на время анимации

  // ── Переход к секции ────────────────────────────────────
  function goTo(index, fromTouch) {
    if (isMoving) return;
    if (index < 0 || index >= TOTAL) return;
    if (index === current) return;

    isMoving = true;
    current  = index;

    // Смещаем контейнер
    fp.style.transform = `translateY(-${current * 100}vh)`;

    // Обновляем dots
    dots.forEach((d, i) => d.classList.toggle('active', i === current));

    // Обновляем активный nav-link
    const ids = ['hero','services','reviews','contacts','main-footer'];
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.toggle('active', link.getAttribute('href') === '#' + ids[current]);
    });

    // Анимация появления контента секции
    animateSection(sections[current]);

    setTimeout(() => { isMoving = false; }, LOCK_MS);
  }

  // ── Анимация контента при входе ─────────────────────────
  function animateSection(section) {
    const els = section.querySelectorAll(
      '.section-label, .section-title, .service-card, .review-card, .contact-item, .contact-form, .hero-title, .viewer-wrap, .hero-flare'
    );
    els.forEach((el, i) => {
      el.style.opacity   = '0';
      el.style.transform = 'translateY(30px)';
      setTimeout(() => {
        el.style.transition = `opacity 0.7s ease ${i * 0.07}s, transform 0.7s ease ${i * 0.07}s`;
        el.style.opacity    = '1';
        el.style.transform  = 'translateY(0)';
      }, 60);
    });
  }

  // ── Mouse Wheel ─────────────────────────────────────────
  let wheelAccum = 0;
  window.addEventListener('wheel', e => {
    e.preventDefault();
    if (isMoving) return;

    wheelAccum += e.deltaY;
    if (Math.abs(wheelAccum) < 50) return;

    if (wheelAccum > 0) goTo(current + 1);
    else                goTo(current - 1);
    wheelAccum = 0;
  }, { passive: false });

  // ── Keyboard ────────────────────────────────────────────
  window.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown' || e.key === 'PageDown') { e.preventDefault(); goTo(current + 1); }
    if (e.key === 'ArrowUp'   || e.key === 'PageUp')   { e.preventDefault(); goTo(current - 1); }
  });

  // ── Touch / Swipe ────────────────────────────────────────
  let touchStartY = 0;
  window.addEventListener('touchstart', e => {
    touchStartY = e.touches[0].clientY;
  }, { passive: true });

  window.addEventListener('touchend', e => {
    const dy = touchStartY - e.changedTouches[0].clientY;
    if (Math.abs(dy) < 40) return;
    if (dy > 0) goTo(current + 1);
    else        goTo(current - 1);
  }, { passive: true });

  // ── Dot navigation ────────────────────────────────────────
  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      goTo(parseInt(dot.dataset.index));
    });
  });

  // ── Nav links ─────────────────────────────────────────────
  const ids = ['hero', 'services', 'reviews', 'contacts', 'main-footer'];
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', e => {
      const href = link.getAttribute('href').replace('#', '');
      const idx  = ids.indexOf(href);
      if (idx !== -1) {
        e.preventDefault();
        goTo(idx);
      }
    });
  });

  // ── CTA кнопки ────────────────────────────────────────────
  document.querySelectorAll('[href="#services"]').forEach(btn => {
    btn.addEventListener('click', e => { e.preventDefault(); goTo(1); });
  });

  // ── Инициализация — показываем первую секцию ────────────
  fp.style.transform = 'translateY(0)';
  dots[0].classList.add('active');
  setTimeout(() => animateSection(sections[0]), 300);

})();
