/**
 * main.js — Кастомный курсор, навигация, scroll-эффекты, форма
 */
(function () {
  'use strict';

  // ── Рассеянный свет под курсором ──────────────────────
  const cursorGlow = document.createElement('div');
  cursorGlow.id = 'cursor-glow';
  cursorGlow.style.cssText = `
    position: fixed;
    pointer-events: none;
    z-index: 9990;
    width: 320px;
    height: 320px;
    border-radius: 50%;
    transform: translate(-50%, -50%);
    background: radial-gradient(
      circle,
      rgba(255,255,255,0.13) 0%,
      rgba(255,255,255,0.07) 25%,
      rgba(200,210,255,0.03) 55%,
      transparent 75%
    );
    filter: blur(18px);
    transition: opacity 0.4s ease;
    opacity: 0;
    mix-blend-mode: screen;
  `;
  document.body.appendChild(cursorGlow);

  // ── Кастомный курсор ──────────────────────────────────
  const cursorOuter = document.getElementById('cursor-outer');
  const cursorInner = document.getElementById('cursor-inner');
  let cursorX = 0, cursorY = 0;
  let outerX  = 0, outerY  = 0;
  let glowX   = 0, glowY   = 0;
  let rafCursor = null;   // ID для RAF — null когда остановлен
  let idleTimer = null;   // таймер остановки после бездействия

  // Запуск RAF только при движении мыши
  function startCursorRAF() {
    if (rafCursor) return; // уже крутится
    function tick() {
      outerX += (cursorX - outerX) * 0.12;
      outerY += (cursorY - outerY) * 0.12;
      cursorOuter.style.left = outerX + 'px';
      cursorOuter.style.top  = outerY + 'px';

      glowX += (cursorX - glowX) * 0.06;
      glowY += (cursorY - glowY) * 0.06;
      cursorGlow.style.left = glowX + 'px';
      cursorGlow.style.top  = glowY + 'px';

      // Остановить если всё сошлось (экономия ~60 fps впустую)
      const dOuter = Math.abs(cursorX - outerX) + Math.abs(cursorY - outerY);
      const dGlow  = Math.abs(cursorX - glowX)  + Math.abs(cursorY - glowY);
      if (dOuter < 0.3 && dGlow < 0.3) {
        rafCursor = null;
        return;
      }
      rafCursor = requestAnimationFrame(tick);
    }
    rafCursor = requestAnimationFrame(tick);
  }

  document.addEventListener('mousemove', e => {
    cursorX = e.clientX;
    cursorY = e.clientY;

    // Inner — мгновенно
    cursorInner.style.left = cursorX + 'px';
    cursorInner.style.top  = cursorY + 'px';

    cursorGlow.style.opacity = '1';
    startCursorRAF();
  }, { passive: true });

  // Эффекты на hover
  const hoverTargets = document.querySelectorAll('a, button, .service-card, .upload-btn, label');
  hoverTargets.forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursorOuter.style.transform = 'translate(-50%, -50%) scale(1.5)';
      cursorOuter.style.borderColor = 'rgba(255,255,255,0.8)';
      cursorInner.style.transform  = 'translate(-50%, -50%) scale(0.3)';
      // Glow ярче и больше на интерактивных элементах
      cursorGlow.style.width  = '460px';
      cursorGlow.style.height = '460px';
      cursorGlow.style.background = `radial-gradient(
        circle,
        rgba(255,255,255,0.2) 0%,
        rgba(255,255,255,0.1) 20%,
        rgba(200,215,255,0.05) 50%,
        transparent 72%
      )`;
    });
    el.addEventListener('mouseleave', () => {
      cursorOuter.style.transform = 'translate(-50%, -50%) scale(1)';
      cursorOuter.style.borderColor = 'rgba(200,200,200,0.5)';
      cursorInner.style.transform  = 'translate(-50%, -50%) scale(1)';
      // Glow возвращается к базовому
      cursorGlow.style.width  = '320px';
      cursorGlow.style.height = '320px';
      cursorGlow.style.background = `radial-gradient(
        circle,
        rgba(255,255,255,0.13) 0%,
        rgba(255,255,255,0.07) 25%,
        rgba(200,210,255,0.03) 55%,
        transparent 75%
      )`;
    });
  });

  // Скрыть при выходе с экрана
  document.addEventListener('mouseleave', () => {
    cursorOuter.style.opacity = '0';
    cursorInner.style.opacity = '0';
    cursorGlow.style.opacity  = '0';
  });
  document.addEventListener('mouseenter', () => {
    cursorOuter.style.opacity = '1';
    cursorInner.style.opacity = '1';
    cursorGlow.style.opacity  = '1';
  });

  // ── Навигация — scroll класс ──────────────────────────
  const nav = document.getElementById('main-nav');
  function updateNav() {
    if (window.scrollY > 50) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', updateNav, { passive: true });
  updateNav();
  // ── Active nav link ────────────────────────────────────
  const sections = document.querySelectorAll('section[id], footer[id]');
  const navLinks  = document.querySelectorAll('.nav-link');

  // ─────────────────────────────────────────────────────
  // Все анимации и reveal-эффекты запускаются только
  // после события preloaderDone (прелоадер полностью закрыт)
  // ─────────────────────────────────────────────────────
  function onPreloaderDone() {

  // ── Active nav link observer ──────────────────────────

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + entry.target.id) {
            link.classList.add('active');
          }
        });
      }
    });
  }, { threshold: 0.4 });

  sections.forEach(s => observer.observe(s));

  // ── Smooth scroll для якорей ──────────────────────────
  navLinks.forEach(link => {
    link.addEventListener('click', e => {
      const href = link.getAttribute('href');
      if (href.startsWith('#')) {
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  });

  // ── Service cards — stagger reveal ────────────────────
  const cards = document.querySelectorAll('.service-card, .review-card');
  const cardObserver = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity   = '1';
          entry.target.style.transform = 'translateY(0)';
        }, i * 100);
        cardObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  cards.forEach(card => {
    card.style.opacity   = '0';
    card.style.transform = 'translateY(40px)';
    card.style.transition = 'opacity 0.7s cubic-bezier(0.25,0.46,0.45,0.94), transform 0.7s cubic-bezier(0.25,0.46,0.45,0.94)';
    cardObserver.observe(card);
  });

  // ── Section titles — reveal ────────────────────────────
  const sectionTitles = document.querySelectorAll('.section-title, .section-label');
  const titleObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity   = '1';
        entry.target.style.transform = 'translateY(0)';
        titleObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  sectionTitles.forEach(el => {
    el.style.opacity   = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.9s cubic-bezier(0.25,0.46,0.45,0.94), transform 0.9s cubic-bezier(0.25,0.46,0.45,0.94)';
    titleObserver.observe(el);
  });

  // ── Contact info items — reveal ───────────────────────
  const contactItems = document.querySelectorAll('.contact-item');
  const contactObserver = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity   = '1';
          entry.target.style.transform = 'translateX(0)';
        }, i * 120);
        contactObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  contactItems.forEach(item => {
    item.style.opacity   = '0';
    item.style.transform = 'translateX(-30px)';
    item.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
    contactObserver.observe(item);
  });

  // ── Форма ──────────────────────────────────────────────
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn  = form.querySelector('.submit-btn span');
      const orig = btn.textContent;

      btn.textContent = '✓ Отправлено';
      form.style.opacity = '0.7';

      setTimeout(() => {
        btn.textContent    = orig;
        form.style.opacity = '1';
        form.reset();
      }, 3000);
    });
  }

  // ── Parallax hero content on scroll — отключён ────────

  // ── Scroll progress line ───────────────────────────────
  const progressBar = document.createElement('div');
  progressBar.style.cssText = `
    position: fixed;
    top: 0; left: 0;
    height: 1px;
    width: 0;
    background: linear-gradient(90deg, transparent, #888 20%, #fff 50%, #888 80%, transparent);
    z-index: 200;
    pointer-events: none;
    transition: width 0.1s linear;
  `;
  document.body.appendChild(progressBar);

  window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    progressBar.style.width = pct + '%';
  }, { passive: true });

  // ── Nav link active CSS ───────────────────────────────
  const navStyle = document.createElement('style');
  navStyle.textContent = `.nav-link.active { color: #fff; } .nav-link.active::after { width: 100%; }`;
  document.head.appendChild(navStyle);

  } // конец onPreloaderDone

  // Вешаем на событие прелоадера; если прелоадера нет — запускаем сразу
  document.addEventListener('preloaderDone', onPreloaderDone, { once: true });
  if (!document.getElementById('preloader')) {
    onPreloaderDone();
  }

  // ── Побуквенная анимация заголовка Hero ───────────────
  // Запускается после закрытия прелоадера
  document.addEventListener('preloaderDone', function initHeroTypewriter() {
    const title = document.getElementById('hero-title');
    if (!title) return;

    // Делаем заголовок видимым — прелоадер уже закрылся
    title.style.visibility = 'visible';

    const BASE_DELAY = 400;  // пауза перед стартом (мс)
    const CHAR_DELAY = 90;   // задержка между буквами (мс)
    const LINE_GAP   = 200;  // доп. пауза между строками (мс)

    const lines = title.querySelectorAll('.line-wrap');
    let globalIdx = 0;

    lines.forEach((line, lineIdx) => {
      const inner = line.querySelector('span') || line;
      const text   = inner.textContent;
      inner.textContent = '';

      [...text].forEach((char) => {
        const span = document.createElement('span');
        const delay = BASE_DELAY + lineIdx * LINE_GAP + globalIdx * CHAR_DELAY;

        if (char === ' ') {
          span.className = 'hero-char hero-char--space';
          span.textContent = '\u00A0'; // неразрывный пробел
        } else {
          span.className = 'hero-char';
          span.textContent = char;
        }

        span.style.animationDelay = delay + 'ms';
        inner.appendChild(span);
        globalIdx++;
      });
    });

    // Показать .viewer-label когда закончится последний символ
    // lastChar delay + длительность анимации charReveal (1100ms) + небольшой буфер
    const lastCharDelay = BASE_DELAY + (lines.length - 1) * LINE_GAP + (globalIdx - 1) * CHAR_DELAY;
    const labelDelay = lastCharDelay + 1100 + 100;
    const label = document.querySelector('.viewer-label');
    if (label) {
      setTimeout(() => label.classList.add('is-visible'), labelDelay);
    }
  }, { once: true });

  console.log('🎬 МФЦ — Cinematic site initialized');
})();
