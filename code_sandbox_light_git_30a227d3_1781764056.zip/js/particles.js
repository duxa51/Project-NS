/**
 * particles.js — ES Module (оптимизированная версия)
 *
 * Что срезано для производительности:
 *  — Звёзды: 3500 → 1200
 *  — Пыль: 900 → 0 (убрана — дорогой CPU-апдейт каждый кадр)
 *  — Орбы (SphereGeometry × 16): убраны
 *  — Стримеры (18 Line + opacity update): убраны
 *  — GridHelper 2400×50: убрана
 *  — Constellation lines: 90 → 40
 *  — Glow plane: оставлен (дёшев — один quad)
 *  — CPU-апдейт позиций звёзд: убран, вращение сцены заменяет движение
 *  — pixelRatio: ограничен до 1
 *  — Анимация паузится через IntersectionObserver когда canvas вне экрана
 */
import * as THREE from 'three';

(function () {
  'use strict';

  const bgCanvas = document.getElementById('bg-canvas');
  if (!bgCanvas) return;

  // ── Renderer ──────────────────────────────────────────
  const renderer = new THREE.WebGLRenderer({
    canvas: bgCanvas,
    antialias: false,
    alpha: false,
    powerPreference: 'low-power'   // просим GPU не гнать на полную
  });
  renderer.setPixelRatio(1);       // всегда 1 — главная экономия на ретина
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setClearColor(0x000000, 1);

  const scene  = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 2000);
  camera.position.z = 600;

  // ── Mouse parallax ────────────────────────────────────
  const mouse  = { x: 0, y: 0 };
  const camTgt = { x: 0, y: 0 };
  let mouseMoved = false;
  document.addEventListener('mousemove', e => {
    mouse.x = (e.clientX / window.innerWidth  - 0.5) * 2;
    mouse.y = (e.clientY / window.innerHeight - 0.5) * 2;
    mouseMoved = true;
  }, { passive: true });

  // ══════════════════════════════════════════════════════
  //  1. ЗВЁЗДЫ — 1200 шт (было 3500)
  //     Позиции НЕ обновляются на CPU каждый кадр —
  //     вместо этого вся группа медленно вращается
  // ══════════════════════════════════════════════════════
  const STAR_N = 1200;
  const sGeo   = new THREE.BufferGeometry();
  const sPos   = new Float32Array(STAR_N * 3);
  const sAlpha = new Float32Array(STAR_N);
  const sSize  = new Float32Array(STAR_N);

  for (let i = 0; i < STAR_N; i++) {
    const i3 = i * 3;
    sPos[i3]     = (Math.random() - 0.5) * 1600;
    sPos[i3 + 1] = (Math.random() - 0.5) * 1600;
    sPos[i3 + 2] = (Math.random() - 0.5) * 1000;
    sAlpha[i]    = Math.random();
    sSize[i]     = Math.random();
  }
  sGeo.setAttribute('position', new THREE.BufferAttribute(sPos, 3));
  sGeo.setAttribute('alpha',    new THREE.BufferAttribute(sAlpha, 1));
  sGeo.setAttribute('aSize',    new THREE.BufferAttribute(sSize, 1));

  const starMat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 } },
    vertexShader: `
      attribute float alpha;
      attribute float aSize;
      uniform float uTime;
      varying float vA;
      varying float vTwinkle;
      void main() {
        vA       = alpha;
        vTwinkle = 0.5 + 0.5 * sin(uTime * 2.0 + alpha * 37.1 + aSize * 13.0);
        vec4 mv  = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = (1.0 + aSize * 2.0 + vTwinkle * 1.2) * (300.0 / -mv.z);
        gl_Position  = projectionMatrix * mv;
      }
    `,
    fragmentShader: `
      varying float vA;
      varying float vTwinkle;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        if (d > 0.5) discard;
        float soft = smoothstep(0.5, 0.05, d);
        float a    = soft * vTwinkle * (0.2 + vA * 0.8);
        vec3 col   = mix(vec3(0.5, 0.5, 0.55), vec3(1.0, 1.0, 1.0), vA);
        gl_FragColor = vec4(col, a);
      }
    `,
    transparent: true,
    depthWrite:  false,
    blending:    THREE.AdditiveBlending
  });

  const stars = new THREE.Points(sGeo, starMat);
  scene.add(stars);

  // ══════════════════════════════════════════════════════
  //  2. CONSTELLATION LINES — 40 шт (было 90)
  //     Статичные, без обновления каждый кадр
  // ══════════════════════════════════════════════════════
  const LINE_N = 40;
  const lGeo   = new THREE.BufferGeometry();
  const lPos   = new Float32Array(LINE_N * 2 * 3);

  for (let i = 0; i < LINE_N; i++) {
    const i6 = i * 6;
    const ax = (Math.random() - 0.5) * 1400;
    const ay = (Math.random() - 0.5) * 1400;
    const az = (Math.random() - 0.5) * 600;
    lPos[i6]     = ax;
    lPos[i6 + 1] = ay;
    lPos[i6 + 2] = az;
    lPos[i6 + 3] = ax + (Math.random() - 0.5) * 280;
    lPos[i6 + 4] = ay + (Math.random() - 0.5) * 280;
    lPos[i6 + 5] = az;
  }
  lGeo.setAttribute('position', new THREE.BufferAttribute(lPos, 3));
  const lMat = new THREE.LineBasicMaterial({
    color: 0x555566, transparent: true, opacity: 0.18,
    blending: THREE.AdditiveBlending, depthWrite: false
  });
  const constellLines = new THREE.LineSegments(lGeo, lMat);
  scene.add(constellLines);

  // ══════════════════════════════════════════════════════
  //  3. GLOW PLANE — один дешёвый quad в центре
  // ══════════════════════════════════════════════════════
  const glowMat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 } },
    vertexShader: `
      varying vec2 vUv;
      void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }
    `,
    fragmentShader: `
      uniform float uTime;
      varying vec2 vUv;
      void main() {
        vec2  uv2  = vUv - 0.5;
        float d    = length(uv2);
        float pulse = 0.5 + 0.5 * sin(uTime * 0.5);
        float a   = smoothstep(0.5, 0.0, d) * (0.05 + 0.03 * pulse);
        vec3  col = mix(vec3(0.3, 0.32, 0.4), vec3(0.85, 0.88, 1.0), 1.0 - d * 2.0);
        gl_FragColor = vec4(col, a);
      }
    `,
    transparent: true, depthWrite: false,
    blending: THREE.AdditiveBlending, side: THREE.DoubleSide
  });
  const glowPlane = new THREE.Mesh(new THREE.PlaneGeometry(1000, 1000), glowMat);
  glowPlane.position.z = -250;
  scene.add(glowPlane);

  // ══════════════════════════════════════════════════════
  //  ANIMATE — с паузой через Visibility API
  // ══════════════════════════════════════════════════════
  let isVisible = true;
  let rafId = null;
  const clock = new THREE.Clock();

  // Пауза когда вкладка скрыта
  document.addEventListener('visibilitychange', () => {
    isVisible = !document.hidden;
    if (isVisible && !rafId) loop();
  });

  // Пауза когда canvas далеко от вьюпорта (скролл вниз)
  const visObs = new IntersectionObserver(([entry]) => {
    isVisible = entry.isIntersecting;
    if (isVisible && !rafId) loop();
  }, { rootMargin: '100px' });
  visObs.observe(bgCanvas);

  function loop() {
    if (!isVisible) { rafId = null; return; }
    rafId = requestAnimationFrame(loop);

    const dt = clock.getDelta();
    const t  = clock.elapsedTime;

    starMat.uniforms.uTime.value = t;
    glowMat.uniforms.uTime.value = t;

    // Медленное вращение вместо CPU-апдейта позиций
    stars.rotation.z          += 0.00005;
    constellLines.rotation.z  += 0.00003;

    // Параллакс камеры — только если мышь двигалась
    if (mouseMoved) {
      camTgt.x += (mouse.x * 30 - camTgt.x) * 0.02;
      camTgt.y += (-mouse.y * 30 - camTgt.y) * 0.02;
      camera.position.x = camTgt.x;
      camera.position.y = camTgt.y;
      camera.lookAt(scene.position);
    }

    renderer.render(scene, camera);
  }
  loop();

  // ── Resize — throttled ────────────────────────────────
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    }, 200);
  }, { passive: true });

})();
