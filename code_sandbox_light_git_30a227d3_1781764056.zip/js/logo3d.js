/**
 * logo3d.js — ES Module (оптимизированная версия)
 *
 * Что срезано:
 *  — antialias: false (было true) — главная экономия GPU
 *  — pixelRatio: min(dpr, 1.5) → min(dpr, 1) — вдвое меньше пикселей на ретина
 *  — shadowMap: отключены (castShadow/receiveShadow = false)
 *  — 9 источников света → 5 (убраны sweepLight, topLight, fillBottom, rimLight)
 *  — Анимация паузится через visibilitychange и IntersectionObserver
 *  — sweepLight заменён простым вращением AmbientLight (нет отдельного объекта)
 *  — rimLight: убран, fillBack остался
 */
import * as THREE        from 'three';
import { GLTFLoader }    from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader }     from 'three/addons/loaders/FBXLoader.js';
import { OBJLoader }     from 'three/addons/loaders/OBJLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// ── DOM ──────────────────────────────────────────────────
const logoCanvas = document.getElementById('logo-canvas');
const dropZone   = document.getElementById('drop-zone');
const fileInput  = document.getElementById('model-file');
const wrap       = document.getElementById('viewer-wrap');
if (!logoCanvas || !wrap) throw new Error('viewer elements not found');

// ── Renderer ─────────────────────────────────────────────
const renderer = new THREE.WebGLRenderer({
  canvas: logoCanvas,
  antialias: false,           // ВЫКЛ — даёт +30-40% fps на сложных сценах
  alpha: true,
  powerPreference: 'default'
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1)); // max 1 пиксель
renderer.setSize(wrap.clientWidth, wrap.clientHeight);
renderer.setClearColor(0x000000, 0);
renderer.toneMapping         = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 2.2;
renderer.outputColorSpace    = THREE.SRGBColorSpace;
renderer.shadowMap.enabled   = false;   // тени отключены

// ── Scene & Camera ────────────────────────────────────────
const scene  = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(38, wrap.clientWidth / wrap.clientHeight, 0.01, 1000);
camera.position.set(0, 0.3, 5);

// ── Orbit Controls ────────────────────────────────────────
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping   = true;
controls.dampingFactor   = 0.05;
controls.enableZoom      = false;
controls.autoRotate      = true;
controls.autoRotateSpeed = 0.8;
controls.enablePan       = false;

// ══════════════════════════════════════════════════════════
//  ОСВЕЩЕНИЕ — 5 источников вместо 9
// ══════════════════════════════════════════════════════════

// 1. Ambient — базовый свет со всех сторон
scene.add(new THREE.AmbientLight(0xffffff, 2.0));

// 2. Key — главный прожектор сверху-спереди (без теней)
const keyLight = new THREE.SpotLight(0xffffff, 180);
keyLight.position.set(3, 6, 4);
keyLight.angle    = 0.5;
keyLight.penumbra = 0.4;
keyLight.decay    = 1.5;
keyLight.distance = 40;
// castShadow намеренно не включаем
scene.add(keyLight);
scene.add(keyLight.target);

// 3. Fill Left
const fillLeft = new THREE.DirectionalLight(0xffffff, 2.2);
fillLeft.position.set(-6, 2, 3);
scene.add(fillLeft);

// 4. Fill Right
const fillRight = new THREE.DirectionalLight(0xffffff, 2.2);
fillRight.position.set(6, 2, 3);
scene.add(fillRight);

// 5. Fill Back
const fillBack = new THREE.DirectionalLight(0xaabbcc, 1.5);
fillBack.position.set(0, 0, -6);
scene.add(fillBack);

// ── HDR Environment Map ───────────────────────────────────
const pmrem = new THREE.PMREMGenerator(renderer);
pmrem.compileEquirectangularShader();

const EW = 16, EH = 8;
const envData = new Uint8Array(EW * EH * 4);
for (let y = 0; y < EH; y++) {
  for (let x = 0; x < EW; x++) {
    const idx = (y * EW + x) * 4;
    const fx = x / EW, fy = y / EH;
    let r = 80, g = 80, b = 90;
    if (fx > 0.55 && fx < 0.78 && fy < 0.35) { r = 255; g = 255; b = 255; }
    if (fx > 0.05 && fx < 0.28 && fy < 0.4)  { r = 120; g = 150; b = 255; }
    if (fx > 0.4  && fx < 0.6  && fy < 0.22) { r = 255; g = 255; b = 255; }
    if (fx < 0.15 && fy > 0.3  && fy < 0.7)  { r = 160; g = 160; b = 180; }
    if (fx > 0.85 && fy > 0.3  && fy < 0.7)  { r = 160; g = 160; b = 180; }
    if (fx > 0.08 && fx < 0.45 && fy > 0.25 && fy < 0.6) { r = 100; g = 110; b = 140; }
    if (fy > 0.72) { r = 70; g = 70; b = 80; }
    envData[idx] = r; envData[idx+1] = g; envData[idx+2] = b; envData[idx+3] = 255;
  }
}
const envTex = new THREE.DataTexture(envData, EW, EH, THREE.RGBAFormat);
envTex.mapping     = THREE.EquirectangularReflectionMapping;
envTex.needsUpdate = true;
scene.environment  = pmrem.fromEquirectangular(envTex).texture;

// ── Metallic material ─────────────────────────────────────
function makeMetalMat() {
  return new THREE.MeshStandardMaterial({
    color:           new THREE.Color(0xc8c8c8),
    metalness:       1.0,
    roughness:       0.18,
    envMapIntensity: 4.0,
  });
}

// ── Install model ─────────────────────────────────────────
let currentModel = null;

function installModel(obj) {
  if (currentModel) scene.remove(currentModel);

  obj.traverse(child => {
    if (child.isMesh) {
      child.material      = makeMetalMat();
      child.castShadow    = false;
      child.receiveShadow = false;
    }
  });

  const box    = new THREE.Box3().setFromObject(obj);
  const size   = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  const scale = 2.8 / Math.max(size.x, size.y, size.z);
  obj.scale.setScalar(scale);
  obj.position.sub(center.multiplyScalar(scale));

  scene.add(obj);
  currentModel = obj;

  keyLight.target.position.set(0, 0, 0);

  if (dropZone) {
    dropZone.style.transition = 'opacity 0.6s';
    dropZone.style.opacity    = '0';
    setTimeout(() => { dropZone.style.display = 'none'; }, 650);
  }

  camera.position.set(0, 0.5, 5);
  controls.reset();
  console.log('✅ 3D модель установлена');
}

// ── Загрузка из ArrayBuffer ───────────────────────────────
function loadFromBuffer(buffer, ext) {
  const url = URL.createObjectURL(new Blob([buffer]));
  const onLoad = obj => { installModel(obj); hideLoading(); };

  if (ext === 'glb' || ext === 'gltf') {
    new GLTFLoader().load(url, gltf => onLoad(gltf.scene));
  } else if (ext === 'fbx') {
    new FBXLoader().load(url, fbx  => onLoad(fbx));
  } else if (ext === 'obj') {
    new OBJLoader().load(url, obj  => onLoad(obj));
  }
}

// ── IndexedDB ─────────────────────────────────────────────
const DB_NAME = 'mfc3d', DB_STORE = 'model', DB_KEY = 'logo';

function openDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, 1);
    r.onupgradeneeded = e => e.target.result.createObjectStore(DB_STORE);
    r.onsuccess = e => res(e.target.result);
    r.onerror   = e => rej(e);
  });
}

async function saveModel(buffer, ext) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).put({ buffer, ext }, DB_KEY);
    tx.oncomplete = res; tx.onerror = rej;
  });
}

async function loadSavedModel() {
  try {
    const db = await openDB();
    return new Promise(res => {
      const r = db.transaction(DB_STORE, 'readonly').objectStore(DB_STORE).get(DB_KEY);
      r.onsuccess = e => res(e.target.result || null);
      r.onerror   = ()  => res(null);
    });
  } catch { return null; }
}

// ── Loading UI ────────────────────────────────────────────
const loadingEl = document.createElement('div');
loadingEl.className = 'model-loading';
loadingEl.innerHTML = '<div class="model-loading__spinner"></div><span>Загрузка модели…</span>';
loadingEl.style.display = 'none';
wrap.appendChild(loadingEl);

function showLoading() { loadingEl.style.display = 'flex'; }
function hideLoading()  { loadingEl.style.display = 'none'; }

// ── Обработка файла ───────────────────────────────────────
async function handleFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['glb','gltf','fbx','obj'].includes(ext)) {
    alert('Поддерживаемые форматы: GLB, GLTF, FBX, OBJ'); return;
  }
  showLoading();
  const buffer = await file.arrayBuffer();
  await saveModel(buffer, ext);
  loadFromBuffer(buffer, ext);
}

// ── File input & Drag-and-Drop ────────────────────────────
fileInput?.addEventListener('change', e => {
  if (e.target.files[0]) handleFile(e.target.files[0]);
});

wrap.addEventListener('dragover',  e => { e.preventDefault(); dropZone?.classList.add('drag-over'); });
wrap.addEventListener('dragleave', ()  => { dropZone?.classList.remove('drag-over'); });
wrap.addEventListener('drop', e => {
  e.preventDefault();
  dropZone?.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});

// ── Авто-загрузка из IndexedDB ────────────────────────────
(async () => {
  const saved = await loadSavedModel();
  if (saved) {
    showLoading();
    if (dropZone) { dropZone.style.opacity = '0'; dropZone.style.pointerEvents = 'none'; }
    loadFromBuffer(saved.buffer, saved.ext);
  }
})();

// ── Render loop с паузой ──────────────────────────────────
let isVisible = true;
let rafId = null;
let t = 0;

document.addEventListener('visibilitychange', () => {
  isVisible = !document.hidden;
  if (isVisible && !rafId) loop();
});

// Пауза когда viewer вне вьюпорта
const visObs = new IntersectionObserver(([entry]) => {
  isVisible = entry.isIntersecting;
  if (isVisible && !rafId) loop();
}, { rootMargin: '50px' });
visObs.observe(logoCanvas);

function loop() {
  if (!isVisible) { rafId = null; return; }
  rafId = requestAnimationFrame(loop);
  t += 0.005;

  // Лёгкое покачивание key-света вместо полноценного sweep
  keyLight.position.x = 3 + Math.sin(t * 0.4) * 1.5;
  keyLight.position.y = 6 + Math.cos(t * 0.3) * 1.0;

  controls.update();
  renderer.render(scene, camera);
}
loop();

// ── Resize ────────────────────────────────────────────────
new ResizeObserver(() => {
  const w = wrap.clientWidth, h = wrap.clientHeight;
  if (w === 0 || h === 0) return;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}).observe(wrap);
