/**
 * logo3d-contacts.js — ES Module
 * Второй 3D вьюер для секции "Контакты".
 * Читает ту же модель из IndexedDB что и основной вьюер (logo3d.js).
 * Лёгкая версия: без OrbitControls drag, только autoRotate.
 */
import * as THREE     from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader }  from 'three/addons/loaders/FBXLoader.js';
import { OBJLoader }  from 'three/addons/loaders/OBJLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const canvas = document.getElementById('contacts-canvas');
const wrap   = document.getElementById('contacts-viewer-wrap');
const hint   = wrap?.querySelector('.contacts-viewer__hint');
if (!canvas || !wrap) throw new Error('contacts viewer: elements not found');

// ── Renderer ─────────────────────────────────────────────
const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: false,
  alpha: true,
  powerPreference: 'default'
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1));
renderer.setSize(wrap.clientWidth, wrap.clientHeight);
renderer.setClearColor(0x000000, 0);
renderer.toneMapping         = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 2.2;
renderer.outputColorSpace    = THREE.SRGBColorSpace;

// ── Scene & Camera ────────────────────────────────────────
const scene  = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(38, wrap.clientWidth / wrap.clientHeight, 0.01, 1000);
camera.position.set(0, 0.3, 5);

// ── Orbit Controls ────────────────────────────────────────
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping   = true;
controls.dampingFactor   = 0.05;
controls.enableZoom      = false;
controls.autoRotate      = true;
controls.autoRotateSpeed = 0.6;
controls.enablePan       = false;

// ── Освещение (идентично logo3d.js) ──────────────────────
scene.add(new THREE.AmbientLight(0xffffff, 2.0));

const keyLight = new THREE.SpotLight(0xffffff, 180);
keyLight.position.set(3, 6, 4);
keyLight.angle = 0.5; keyLight.penumbra = 0.4;
keyLight.decay = 1.5; keyLight.distance = 40;
scene.add(keyLight); scene.add(keyLight.target);

const fillLeft  = new THREE.DirectionalLight(0xffffff, 2.2);
fillLeft.position.set(-6, 2, 3);
scene.add(fillLeft);

const fillRight = new THREE.DirectionalLight(0xffffff, 2.2);
fillRight.position.set(6, 2, 3);
scene.add(fillRight);

const fillBack  = new THREE.DirectionalLight(0xaabbcc, 1.5);
fillBack.position.set(0, 0, -6);
scene.add(fillBack);

// ── Env Map ───────────────────────────────────────────────
const pmrem = new THREE.PMREMGenerator(renderer);
pmrem.compileEquirectangularShader();
const EW = 16, EH = 8;
const envData = new Uint8Array(EW * EH * 4);
for (let y = 0; y < EH; y++) {
  for (let x = 0; x < EW; x++) {
    const idx = (y * EW + x) * 4;
    const fx = x / EW, fy = y / EH;
    let r = 80, g = 80, b = 90;
    if (fx > 0.55 && fx < 0.78 && fy < 0.35) { r=255; g=255; b=255; }
    if (fx > 0.05 && fx < 0.28 && fy < 0.4)  { r=120; g=150; b=255; }
    if (fx > 0.4  && fx < 0.6  && fy < 0.22) { r=255; g=255; b=255; }
    if (fx < 0.15 && fy > 0.3  && fy < 0.7)  { r=160; g=160; b=180; }
    if (fx > 0.85 && fy > 0.3  && fy < 0.7)  { r=160; g=160; b=180; }
    if (fy > 0.72) { r=70; g=70; b=80; }
    envData[idx]=r; envData[idx+1]=g; envData[idx+2]=b; envData[idx+3]=255;
  }
}
const envTex = new THREE.DataTexture(envData, EW, EH, THREE.RGBAFormat);
envTex.mapping = THREE.EquirectangularReflectionMapping;
envTex.needsUpdate = true;
scene.environment = pmrem.fromEquirectangular(envTex).texture;

// ── Metallic material ─────────────────────────────────────
function makeMetalMat() {
  return new THREE.MeshStandardMaterial({
    color: new THREE.Color(0xc8c8c8),
    metalness: 1.0, roughness: 0.18, envMapIntensity: 4.0
  });
}

// ── Установка модели ──────────────────────────────────────
function installModel(obj) {
  obj.traverse(child => {
    if (child.isMesh) { child.material = makeMetalMat(); child.castShadow = false; }
  });
  const box = new THREE.Box3().setFromObject(obj);
  const size = new THREE.Vector3(); const center = new THREE.Vector3();
  box.getSize(size); box.getCenter(center);
  const scale = 2.8 / Math.max(size.x, size.y, size.z);
  obj.scale.setScalar(scale);
  obj.position.sub(center.multiplyScalar(scale));
  scene.add(obj);
  keyLight.target.position.set(0, 0, 0);
  if (hint) hint.style.display = 'none';
}

function loadFromBuffer(buffer, ext) {
  const url = URL.createObjectURL(new Blob([buffer]));
  const onLoad = obj => installModel(obj);
  if (ext === 'glb' || ext === 'gltf') new GLTFLoader().load(url, g => onLoad(g.scene));
  else if (ext === 'fbx') new FBXLoader().load(url, onLoad);
  else if (ext === 'obj') new OBJLoader().load(url, onLoad);
}

// ── IndexedDB — та же база что и logo3d.js ────────────────
(async () => {
  try {
    const db = await new Promise((res, rej) => {
      const r = indexedDB.open('mfc3d', 1);
      r.onupgradeneeded = e => e.target.result.createObjectStore('model');
      r.onsuccess = e => res(e.target.result);
      r.onerror   = e => rej(e);
    });
    const saved = await new Promise(res => {
      const r = db.transaction('model','readonly').objectStore('model').get('logo');
      r.onsuccess = e => res(e.target.result || null);
      r.onerror   = ()  => res(null);
    });
    if (saved) loadFromBuffer(saved.buffer, saved.ext);
  } catch (_) { /* нет модели — показываем hint */ }
})();

// ── Render loop с паузой ──────────────────────────────────
let isVisible = false;
let rafId = null;
let t = 0;

document.addEventListener('visibilitychange', () => {
  isVisible = !document.hidden;
  if (isVisible && !rafId) loop();
});

const visObs = new IntersectionObserver(([entry]) => {
  isVisible = entry.isIntersecting;
  if (isVisible && !rafId) loop();
}, { rootMargin: '50px' });
visObs.observe(canvas);

function loop() {
  if (!isVisible) { rafId = null; return; }
  rafId = requestAnimationFrame(loop);
  t += 0.005;
  keyLight.position.x = 3 + Math.sin(t * 0.4) * 1.5;
  keyLight.position.y = 6 + Math.cos(t * 0.3) * 1.0;
  controls.update();
  renderer.render(scene, camera);
}

// ── Resize ────────────────────────────────────────────────
new ResizeObserver(() => {
  const w = wrap.clientWidth, h = wrap.clientHeight;
  if (w === 0 || h === 0) return;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}).observe(wrap);
