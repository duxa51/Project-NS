/**
 * scroll-lines.js — Металлические диагональные полосы
 * ─────────────────────────────────────────────────────
 * Полосы перпендикулярны друг другу: левая +35°, правая -35°.
 * Вместе образуют X / пересечение в центре экрана.
 * Въезжают рано (start: 'top 80%') и уходят рано (reviews top).
 */
(function () {
  'use strict';

  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
    console.warn('[scroll-lines] GSAP или ScrollTrigger не найдены');
    return;
  }

  gsap.registerPlugin(ScrollTrigger);

  const bandLeft  = document.getElementById('band-left');
  const bandRight = document.getElementById('band-right');

  if (!bandLeft || !bandRight) {
    console.warn('[scroll-lines] #band-left / #band-right не найдены в DOM');
    return;
  }

  /* ── Начальное состояние ──────────────────────────────
     Левая:  rotation +35° (наклон вправо-вниз), уходит влево
     Правая: rotation -35° (наклон влево-вниз),  уходит вправо
     Вместе при въезде образуют форму X                   */
  gsap.set(bandLeft, {
    rotation: 35,
    x: '-150vw',
    opacity: 0,
    force3D: true
  });

  gsap.set(bandRight, {
    rotation: -35,
    x: '150vw',
    opacity: 0,
    force3D: true
  });

  /* ── Въезд: начинается рано, до конца hero ────────────
     start: 'top 80%'  — начало когда hero ещё на 80% высоты (почти сразу)
     end:   '+=500'    — полный въезд за 500px              */
  const tlIn = gsap.timeline({
    scrollTrigger: {
      trigger: '#hero',
      start: 'top 10%',   // чуть позже начала страницы — появляются рано
      end: '+=500',
      scrub: 1.0,
      // markers: true,
    }
  });

  tlIn.to(bandLeft, {
    x: '0vw',
    opacity: 1,
    duration: 1,
    ease: 'power2.out'
  }, 0);

  tlIn.to(bandRight, {
    x: '0vw',
    opacity: 1,
    duration: 1,
    ease: 'power2.out'
  }, 0.06);

  /* ── Блики по поверхности полос ──────────────────────  */
  let flaresStarted = false;

  function startFlareAnimations() {
    if (flaresStarted) return;
    flaresStarted = true;

    document.querySelectorAll('.metal-band__flare').forEach((flare, i) => {
      gsap.fromTo(flare,
        { left: '-10%', opacity: 0 },
        {
          left: '110%',
          opacity: 1,
          duration: 2.4,
          ease: 'power1.inOut',
          repeat: -1,
          repeatDelay: 2.0 + i * 1.6,
          delay: 0.3 + i * 1.0
        }
      );
    });

    document.querySelectorAll('.metal-band__shine').forEach((shine, i) => {
      gsap.fromTo(shine,
        { opacity: 0.2 },
        {
          opacity: 0.75,
          duration: 1.8,
          ease: 'sine.inOut',
          yoyo: true,
          repeat: -1,
          delay: i * 0.6
        }
      );
    });
  }

  ScrollTrigger.create({
    trigger: '#hero',
    start: 'top+=150 top',
    onEnter: startFlareAnimations,
    once: true
  });

  /* ── Параллакс Y пока видна секция services ───────────  */
  gsap.to(bandLeft, {
    scrollTrigger: {
      trigger: '#services',
      start: 'top bottom',
      end: 'bottom top',
      scrub: 2.5
    },
    y: 80,
    ease: 'none'
  });

  gsap.to(bandRight, {
    scrollTrigger: {
      trigger: '#services',
      start: 'top bottom',
      end: 'bottom top',
      scrub: 2.5
    },
    y: -80,
    ease: 'none'
  });

  /* ── Ранний выход: полосы уходят при входе в services ──
     start: 'top 90%'  — начало исчезновения ранно
     end:   'top 40%'  — полностью исчезают до середины секции */
  const tlOut = gsap.timeline({
    scrollTrigger: {
      trigger: '#services',
      start: 'top 90%',
      end: 'top 40%',
      scrub: 1.4
    }
  });

  tlOut.to(bandLeft, {
    x: '-150vw',
    opacity: 0,
    duration: 1,
    ease: 'power2.in'
  }, 0);

  tlOut.to(bandRight, {
    x: '150vw',
    opacity: 0,
    duration: 1,
    ease: 'power2.in'
  }, 0.06);

  console.log('[scroll-lines] ✅ Металлические полосы инициализированы (X-форма)');

})();
