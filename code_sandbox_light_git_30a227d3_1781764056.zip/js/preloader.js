/**
 * preloader.js
 * Последовательность:
 *  1. Чёрный экран — иконка появляется по центру (scale + fade)
 *  2. От иконки влево и вправо расходятся металлические полосы
 *  3. Экран плавно разделяется: верхняя и нижняя половины расходятся вверх/вниз
 *  4. Прелоадер удаляется, сайт открыт
 */
(function () {
  'use strict';

  /* ── CSS ──────────────────────────────────────────────── */
  const style = document.createElement('style');
  style.textContent = `
    /* ═══ ПРЕЛОАДЕР ══════════════════════════════════════ */
    #preloader {
      position: fixed;
      inset: 0;
      z-index: 10000;
      pointer-events: all;
      overflow: hidden;
    }

    /* Верхняя и нижняя половины — образуют цельный экран */
    .pl-half {
      position: absolute;
      left: 0; right: 0;
      height: 50%;
      background: #000;
      z-index: 3;
      will-change: transform;
    }
    .pl-half--top    { top: 0;    transform: translateY(0); }
    .pl-half--bottom { bottom: 0; transform: translateY(0); }

    /* Фаза split — половины расходятся */
    #preloader.pl-split .pl-half--top {
      transform: translateY(-100%);
      transition: transform 2.4s cubic-bezier(0.76, 0, 0.24, 1);
    }
    #preloader.pl-split .pl-half--bottom {
      transform: translateY(100%);
      transition: transform 2.4s cubic-bezier(0.76, 0, 0.24, 1);
    }

    /* Центральный слой */
    .pl-stage {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 2;
      background: #000;
      opacity: 1;
      transition: opacity 1.1s ease 0.7s;
    }
    /* При split — центр плавно исчезает */
    #preloader.pl-split .pl-stage {
      opacity: 0;
    }

    /* ── Иконка ── */
    .pl-logo {
      width: 200px;
      height: 200px;
      object-fit: contain;
      position: relative;
      z-index: 2;
      opacity: 0;
      transform: scale(0.72);
      filter: drop-shadow(0 0 40px rgba(200,200,220,0.18));
      transition:
        opacity   1.2s cubic-bezier(0.25, 0.46, 0.45, 0.94),
        transform 1.2s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    }
    .pl-logo.pl-logo--visible {
      opacity: 1;
      transform: scale(1);
    }

    /* ── Полосы ── */
    .pl-bands {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 14px;
      pointer-events: none;
      z-index: 1;
    }

    .pl-band {
      position: relative;
      width: 100%;
      height: 1px;
    }
    .pl-band--thick { height: 2px; }

    /* Каждая полоса расходится из центра */
    .pl-band::before,
    .pl-band::after {
      content: '';
      position: absolute;
      top: 0;
      height: 100%;
      width: 0;
      transition: width 1.7s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    }
    .pl-band::before {
      right: 50%;
      background: linear-gradient(to left,
        rgba(255,255,255,0.95) 0%,
        rgba(200,200,200,0.7)  30%,
        rgba(130,130,130,0.3)  70%,
        transparent 100%
      );
    }
    .pl-band::after {
      left: 50%;
      background: linear-gradient(to right,
        rgba(255,255,255,0.95) 0%,
        rgba(200,200,200,0.7)  30%,
        rgba(130,130,130,0.3)  70%,
        transparent 100%
      );
    }

    /* Blur у толстых полос */
    .pl-band--thick::before,
    .pl-band--thick::after {
      filter: blur(0.6px);
    }

    /* Trigger — полосы расходятся */
    #preloader.pl-bands-go .pl-band::before,
    #preloader.pl-bands-go .pl-band::after {
      width: 52vw;
    }

    /* Stagger задержки */
    #preloader.pl-bands-go .pl-band:nth-child(1)::before,
    #preloader.pl-bands-go .pl-band:nth-child(1)::after { transition-delay:   0ms; }
    #preloader.pl-bands-go .pl-band:nth-child(2)::before,
    #preloader.pl-bands-go .pl-band:nth-child(2)::after { transition-delay: 120ms; }
    #preloader.pl-bands-go .pl-band:nth-child(3)::before,
    #preloader.pl-bands-go .pl-band:nth-child(3)::after { transition-delay: 220ms; }
    #preloader.pl-bands-go .pl-band:nth-child(4)::before,
    #preloader.pl-bands-go .pl-band:nth-child(4)::after { transition-delay: 310ms; }
    #preloader.pl-bands-go .pl-band:nth-child(5)::before,
    #preloader.pl-bands-go .pl-band:nth-child(5)::after { transition-delay: 390ms; }
    #preloader.pl-bands-go .pl-band:nth-child(6)::before,
    #preloader.pl-bands-go .pl-band:nth-child(6)::after { transition-delay: 460ms; }
    #preloader.pl-bands-go .pl-band:nth-child(7)::before,
    #preloader.pl-bands-go .pl-band:nth-child(7)::after { transition-delay: 160ms; }

    /* Мягкое свечение под иконкой во время split */
    .pl-glow {
      position: absolute;
      width: 280px;
      height: 280px;
      border-radius: 50%;
      background: radial-gradient(circle,
        rgba(200, 210, 255, 0.12) 0%,
        rgba(150, 160, 220, 0.06) 40%,
        transparent 70%
      );
      pointer-events: none;
      z-index: 0;
      opacity: 0;
      transition: opacity 1.6s ease;
    }
    .pl-glow.pl-glow--on { opacity: 1; }
  `;
  document.head.appendChild(style);

  /* ── DOM ──────────────────────────────────────────────── */
  const overlay = document.createElement('div');
  overlay.id = 'preloader';
  overlay.innerHTML = `
    <div class="pl-half pl-half--top"></div>
    <div class="pl-half pl-half--bottom"></div>

    <div class="pl-stage">
      <div class="pl-glow" id="pl-glow"></div>
      <img
        class="pl-logo"
        id="pl-logo"
        src="images/preloader-logo.png"
        alt="Национальный сервис"
        draggable="false"
      />
      <div class="pl-bands">
        <div class="pl-band"></div>
        <div class="pl-band pl-band--thick"></div>
        <div class="pl-band"></div>
        <div class="pl-band pl-band--thick"></div>
        <div class="pl-band"></div>
        <div class="pl-band pl-band--thick"></div>
        <div class="pl-band"></div>
      </div>
    </div>
  `;
  document.body.insertBefore(overlay, document.body.firstChild);

  /* ── Блокируем скролл ─────────────────────────────────── */
  document.body.style.overflow = 'hidden';

  /* ── Последовательность ───────────────────────────────── */
  const logo = document.getElementById('pl-logo');
  const glow = document.getElementById('pl-glow');

  function run() {
    // Шаг 1: иконка появляется — сразу после загрузки картинки
    function showLogo() {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          logo.classList.add('pl-logo--visible');
        });
      });
    }
    if (logo.complete && logo.naturalWidth) {
      showLogo();
    } else {
      logo.addEventListener('load', showLogo, { once: true });
      // Страховка — если load не придёт
      setTimeout(showLogo, 300);
    }

    // Шаг 2: полосы расходятся
    setTimeout(() => {
      overlay.classList.add('pl-bands-go');
      glow.classList.add('pl-glow--on');
    }, 1200);

    // Шаг 3: split — половины расходятся
    setTimeout(() => {
      overlay.classList.add('pl-split');
    }, 3100);

    // Шаг 4: убираем прелоадер плавно — fade всего overlay
    setTimeout(() => {
      overlay.style.pointerEvents = 'none';
      overlay.style.transition = 'opacity 1.0s ease';
      overlay.style.opacity = '0';
      setTimeout(() => {
        overlay.remove();
        document.body.style.overflow = '';
        // Снимаем заморозку анимаций
        document.body.classList.remove('preloader-active');
        // Сообщаем остальному JS что прелоадер закрылся
        document.dispatchEvent(new CustomEvent('preloaderDone'));
      }, 1050);
    }, 5700);
  }

  /* ── Старт после загрузки страницы ───────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

})();
