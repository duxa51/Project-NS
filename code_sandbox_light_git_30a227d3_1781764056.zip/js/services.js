/**
 * services.js — Рендер карточек категорий и модального окна
 * Телефон для звонка: 8(3952)718888
 */
(function () {
  'use strict';

  const PHONE = '83952718888';
  const PHONE_DISPLAY = '8 (3952) 71-88-88';

  /* ── Ждём DOM ─────────────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', init);

  function pluralServices(n) {
    if (n % 10 === 1 && n % 100 !== 11) return 'услуга';
    if ([2,3,4].includes(n % 10) && ![12,13,14].includes(n % 100)) return 'услуги';
    return 'услуг';
  }

  function init() {
    if (typeof SERVICES_DATA === 'undefined') {
      console.warn('[services] SERVICES_DATA не найден');
      return;
    }
    renderGrid();
    createModal();
  }

  /* ── Рендер сетки карточек ────────────────────────────── */
  function renderGrid() {
    const grid = document.getElementById('services-grid');
    if (!grid) return;

    grid.innerHTML = '';

    SERVICES_DATA.forEach((item, idx) => {
      const card = document.createElement('article');
      card.className = 'service-card';
      card.setAttribute('tabindex', '0');
      card.setAttribute('role', 'button');
      card.setAttribute('aria-label', `Открыть категорию: ${item.category}`);
      card.dataset.index = idx;

      const count = item.services.length;
      card.innerHTML = `
        <div class="service-card__num">${String(idx + 1).padStart(2, '0')}</div>
        <h3 class="service-card__title">${item.category}</h3>
        ${count > 0 ? `<p class="service-card__count">${count} ${pluralServices(count)}</p>` : ''}
        <div class="service-card__arrow">
          <svg viewBox="0 0 24 24" fill="none" width="18" height="18">
            <path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" stroke-width="1.5"
              stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <div class="card-line"></div>
      `;

      card.addEventListener('click', () => openModal(idx));
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openModal(idx); }
      });

      grid.appendChild(card);
    });
  }

  /* ── Создание модального окна (один раз) ─────────────── */
  function createModal() {
    if (document.getElementById('services-modal')) return;

    const overlay = document.createElement('div');
    overlay.id = 'services-modal';
    overlay.className = 'svc-modal';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-hidden', 'true');

    overlay.innerHTML = `
      <div class="svc-modal__backdrop"></div>
      <div class="svc-modal__panel">
        <button class="svc-modal__close" id="modal-close" aria-label="Закрыть">
          <svg viewBox="0 0 24 24" fill="none" width="22" height="22">
            <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="1.5"
              stroke-linecap="round"/>
          </svg>
        </button>
        <div class="svc-modal__header">
          <span class="svc-modal__icon" id="modal-icon"></span>
          <h2 class="svc-modal__title" id="modal-title"></h2>
        </div>
        <p class="svc-modal__hint">Выберите услугу, чтобы связаться с нами</p>
        <ul class="svc-modal__list" id="modal-list"></ul>
        <div class="svc-modal__footer">
          <a href="tel:${PHONE}" class="svc-modal__phone">
            <svg viewBox="0 0 24 24" fill="none" width="18" height="18">
              <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.09 9.8 19.79 19.79 0 01.04 1.18 2 2 0 012 .01h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92v2z"
                stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            ${PHONE_DISPLAY}
          </a>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    /* Закрытие */
    overlay.querySelector('#modal-close').addEventListener('click', closeModal);
    overlay.querySelector('.svc-modal__backdrop').addEventListener('click', closeModal);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModal();
    });
  }

  /* ── Открытие модального окна ─────────────────────────── */
  function openModal(idx) {
    const data = SERVICES_DATA[idx];
    const modal = document.getElementById('services-modal');
    if (!modal || !data) return;

    modal.querySelector('#modal-icon').textContent = data.icon;
    modal.querySelector('#modal-title').textContent = data.category;

    const list = modal.querySelector('#modal-list');
    list.innerHTML = '';

    if (data.services.length === 0) {
      const li = document.createElement('li');
      li.className = 'svc-modal__item svc-modal__item--empty';
      li.innerHTML = '<span class="svc-modal__empty">Услуги уточняются. Позвоните нам — расскажем подробнее.</span>';
      list.appendChild(li);
    } else {
      data.services.forEach((svc) => {
        const li = document.createElement('li');
        li.className = 'svc-modal__item';

        const a = document.createElement('a');
        a.href = `tel:${PHONE}`;
        a.className = 'svc-modal__service';
        a.setAttribute('aria-label', `Позвонить по услуге: ${svc}`);

        a.innerHTML = `
          <span class="svc-modal__service-text">${svc}</span>
          <span class="svc-modal__call-icon">
            <svg viewBox="0 0 24 24" fill="none" width="16" height="16">
              <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.09 9.8 19.79 19.79 0 01.04 1.18 2 2 0 012 .01h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92v2z"
                stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </span>
        `;

        li.appendChild(a);
        list.appendChild(li);
      });
    }

    /* Показываем */
    modal.setAttribute('aria-hidden', 'false');
    modal.classList.add('is-open');
    document.body.classList.add('modal-open');

    /* Анимация строк с задержкой */
    requestAnimationFrame(() => {
      const items = list.querySelectorAll('.svc-modal__item');
      items.forEach((item, i) => {
        item.style.transitionDelay = `${i * 40}ms`;
        item.classList.add('is-visible');
      });
    });
  }

  /* ── Закрытие ─────────────────────────────────────────── */
  function closeModal() {
    const modal = document.getElementById('services-modal');
    if (!modal) return;
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');

    /* Сбрасываем задержки после закрытия */
    setTimeout(() => {
      const items = modal.querySelectorAll('.svc-modal__item');
      items.forEach((item) => {
        item.classList.remove('is-visible');
        item.style.transitionDelay = '0ms';
      });
    }, 350);
  }

})();
